package sorm.com.zh.core;

/**
 * @author cai-xiansheng
 * @Description
 * @create 2020-08-10 12:18
 */
public class QueryFactory {

    //public Query createQuery();

}
